package com.cg.mra.exception;

public class InvalidMobileNumberexception  extends RuntimeException{

	public InvalidMobileNumberexception() {
		super();
		// TODO Auto-generated constructor stub
	}

	public InvalidMobileNumberexception(String message, Throwable cause, boolean enableSuppression,
			boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
		// TODO Auto-generated constructor stub
	}

	public InvalidMobileNumberexception(String message, Throwable cause) {
		super(message, cause);
		// TODO Auto-generated constructor stub
	}

	public InvalidMobileNumberexception(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	public InvalidMobileNumberexception(Throwable cause) {
		super(cause);
		// TODO Auto-generated constructor stub
	}

}
